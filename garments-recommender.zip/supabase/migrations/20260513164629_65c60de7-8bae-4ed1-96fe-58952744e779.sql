CREATE TABLE public.garments (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  gender TEXT NOT NULL,
  occasion TEXT NOT NULL,
  clothing_type TEXT NOT NULL,
  color TEXT NOT NULL,
  description TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_garments_gender ON public.garments(gender);
CREATE INDEX idx_garments_occasion ON public.garments(occasion);

ALTER TABLE public.garments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Garments are publicly readable"
ON public.garments
FOR SELECT
USING (true);