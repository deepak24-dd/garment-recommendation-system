import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { analyzeOutfit } from "@/lib/outfit.functions";
import { recommendGarments } from "@/lib/recommender.functions";
import type { RecommendResult } from "@/lib/recommender";
import { getGarmentImageUrl } from "@/lib/garment-images";
import { Button } from "@/components/ui/button";
import { Camera, Loader2, Upload, Sparkles, AlertCircle, X } from "lucide-react";

type Analysis = {
  detected_type: string;
  detected_color: string;
  description: string;
  suggested_occasion: string;
};

export function OutfitChecker() {
  const [preview, setPreview] = useState<string | null>(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [matching, setMatching] = useState(false);
  const [analysis, setAnalysis] = useState<Analysis | null>(null);
  const [matches, setMatches] = useState<RecommendResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const analyze = useServerFn(analyzeOutfit);
  const recommend = useServerFn(recommendGarments);

  const onFile = async (file: File) => {
    setError(null);
    setAnalysis(null);
    setMatches(null);
    if (!file.type.startsWith("image/")) {
      setError("Please upload an image file.");
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      setError("Image must be smaller than 5MB.");
      return;
    }
    const dataUrl = await new Promise<string>((resolve, reject) => {
      const r = new FileReader();
      r.onload = () => resolve(r.result as string);
      r.onerror = () => reject(new Error("Failed to read file"));
      r.readAsDataURL(file);
    });
    setPreview(dataUrl);

    setAnalyzing(true);
    try {
      const res = await analyze({ data: { imageDataUrl: dataUrl } });
      setAnalysis(res);
      // Auto-fetch matching color outfits
      setMatching(true);
      const rec = await recommend({
        data: {
          gender: "unisex",
          occasion: res.suggested_occasion,
          clothing_type: "",
          color_preference: res.detected_color,
        },
      });
      setMatches(rec);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Analysis failed.");
    } finally {
      setAnalyzing(false);
      setMatching(false);
    }
  };

  const reset = () => {
    setPreview(null);
    setAnalysis(null);
    setMatches(null);
    setError(null);
  };

  const refineMatches = async (gender: "male" | "female") => {
    if (!analysis) return;
    setMatching(true);
    try {
      const rec = await recommend({
        data: {
          gender,
          occasion: analysis.suggested_occasion,
          clothing_type: "",
          color_preference: analysis.detected_color,
        },
      });
      setMatches(rec);
    } finally {
      setMatching(false);
    }
  };

  return (
    <section id="check-outfit" className="border-t border-border bg-background">
      <div className="mx-auto max-w-6xl px-6 py-16 md:py-24">
        <div className="mb-10 max-w-2xl">
          <p className="text-xs uppercase tracking-[0.25em] text-primary mb-3">Check my outfit</p>
          <h2 className="font-display text-4xl md:text-5xl text-foreground text-balance">
            Upload a photo. Get matching pieces.
          </h2>
          <p className="mt-3 text-muted-foreground">
            We detect the dominant color and clothing type from your photo, then suggest pieces from
            our catalog in the same color family.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {/* Upload pane */}
          <div className="bg-card border border-border p-6">
            {!preview ? (
              <label className="flex flex-col items-center justify-center aspect-[4/5] border-2 border-dashed border-border hover:border-primary/60 cursor-pointer transition-colors group">
                <input
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => e.target.files?.[0] && onFile(e.target.files[0])}
                />
                <Camera className="h-12 w-12 text-muted-foreground group-hover:text-primary transition-colors" strokeWidth={1} />
                <p className="mt-4 font-display text-xl text-foreground">Drop or choose a photo</p>
                <p className="mt-2 text-xs uppercase tracking-wider text-muted-foreground">
                  JPG · PNG · max 5MB
                </p>
                <span className="mt-6 inline-flex items-center gap-2 px-5 py-2.5 border border-border text-sm">
                  <Upload className="h-4 w-4" /> Browse files
                </span>
              </label>
            ) : (
              <div className="relative">
                <div className="aspect-[4/5] overflow-hidden bg-secondary">
                  <img src={preview} alt="Your outfit" className="h-full w-full object-cover" />
                  {analyzing && (
                    <div className="absolute inset-0 bg-background/70 flex flex-col items-center justify-center">
                      <Loader2 className="h-8 w-8 animate-spin text-primary" />
                      <p className="mt-3 text-sm text-foreground">Analyzing your outfit…</p>
                    </div>
                  )}
                </div>
                <button
                  onClick={reset}
                  className="absolute top-3 right-3 h-9 w-9 bg-background/90 border border-border flex items-center justify-center hover:bg-background"
                  aria-label="Remove"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
            )}

            {error && (
              <div className="mt-4 flex items-start gap-2 text-sm text-destructive">
                <AlertCircle className="h-4 w-4 mt-0.5 shrink-0" />
                <p>{error}</p>
              </div>
            )}
          </div>

          {/* Analysis pane */}
          <div className="bg-card border border-border p-6 flex flex-col">
            {!analysis ? (
              <div className="flex-1 flex flex-col items-center justify-center text-center text-muted-foreground">
                <Sparkles className="h-10 w-10 text-primary/40" strokeWidth={1} />
                <p className="mt-4 max-w-xs text-sm">
                  Your detected outfit details and suggested matches will appear here.
                </p>
              </div>
            ) : (
              <div className="flex-1 flex flex-col">
                <p className="text-xs uppercase tracking-[0.2em] text-primary mb-2">Detected</p>
                <p className="font-display text-2xl text-foreground capitalize">
                  {analysis.detected_color} {analysis.detected_type.replace(/_/g, " ")}
                </p>
                <p className="mt-3 text-sm text-muted-foreground leading-relaxed">
                  {analysis.description}
                </p>

                <dl className="mt-6 grid grid-cols-3 gap-3 text-xs">
                  <Stat l="Color" v={analysis.detected_color} />
                  <Stat l="Type" v={analysis.detected_type.replace(/_/g, " ")} />
                  <Stat l="Occasion" v={analysis.suggested_occasion} />
                </dl>

                <div className="mt-auto pt-6">
                  <p className="text-xs uppercase tracking-wider text-muted-foreground mb-2">
                    Refine matches by gender
                  </p>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      onClick={() => refineMatches("male")}
                      disabled={matching}
                      className="rounded-none"
                    >
                      Men's pieces
                    </Button>
                    <Button
                      variant="outline"
                      onClick={() => refineMatches("female")}
                      disabled={matching}
                      className="rounded-none"
                    >
                      Women's pieces
                    </Button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Matches grid */}
        {matches && (
          <div className="mt-14">
            <div className="mb-6 flex items-end justify-between flex-wrap gap-3">
              <h3 className="font-display text-2xl md:text-3xl text-foreground">
                {matches.total > 0
                  ? `${matches.total} pieces in the same color family`
                  : "No matching pieces found — try refining"}
              </h3>
              {matching && <Loader2 className="h-5 w-5 animate-spin text-primary" />}
            </div>
            {matches.total > 0 && (
              <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
                {matches.recommendations.slice(0, 8).map((g) => (
                  <article key={g.id} className="bg-card border border-border group">
                    <div className="aspect-[4/5] overflow-hidden bg-secondary">
                      <img
                        src={getGarmentImageUrl(g)}
                        alt={g.name}
                        loading="lazy"
                        className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-500"
                      />
                    </div>
                    <div className="p-4">
                      <h4 className="font-display text-base text-foreground leading-tight">{g.name}</h4>
                      <p className="mt-1 text-xs text-muted-foreground capitalize">
                        {g.color} · {g.clothing_type.replace(/_/g, " ")}
                      </p>
                    </div>
                  </article>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </section>
  );
}

function Stat({ l, v }: { l: string; v: string }) {
  return (
    <div className="border border-border p-3 bg-background">
      <dt className="text-[10px] uppercase tracking-wider text-muted-foreground">{l}</dt>
      <dd className="mt-1 text-foreground capitalize text-sm">{v}</dd>
    </div>
  );
}
