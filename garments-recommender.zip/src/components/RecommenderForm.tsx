import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { recommendGarments } from "@/lib/recommender.functions";
import {
  COLOR_GROUPS,
  VALID_GENDERS,
  VALID_OCCASIONS,
  type RecommendResult,
} from "@/lib/recommender";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Loader2, Sparkles, Shirt, AlertCircle } from "lucide-react";
import { getGarmentImageUrl } from "@/lib/garment-images";

const cap = (s: string) => s.charAt(0).toUpperCase() + s.slice(1);

export function RecommenderForm() {
  const [gender, setGender] = useState("");
  const [occasion, setOccasion] = useState("");
  const [clothingType, setClothingType] = useState("");
  const [colorPref, setColorPref] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<RecommendResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const recommend = useServerFn(recommendGarments);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (!gender || !occasion) {
      setError("Please choose a gender and an occasion.");
      return;
    }
    setLoading(true);
    try {
      const res = await recommend({
        data: {
          gender,
          occasion,
          clothing_type: clothingType,
          color_preference: colorPref,
        },
      });
      setResult(res);
      setTimeout(() => {
        document.getElementById("results")?.scrollIntoView({ behavior: "smooth", block: "start" });
      }, 50);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong.");
    } finally {
      setLoading(false);
    }
  };

  const reset = () => {
    setGender("");
    setOccasion("");
    setClothingType("");
    setColorPref("");
    setResult(null);
    setError(null);
  };

  const colorGroupNames = Object.keys(COLOR_GROUPS);

  return (
    <>
      <section id="recommend" className="border-t border-border bg-card">
        <div className="mx-auto max-w-5xl px-6 py-16 md:py-24">
          <div className="mb-10">
            <p className="text-xs uppercase tracking-[0.25em] text-primary mb-3">The recommender</p>
            <h2 className="font-display text-4xl md:text-5xl text-foreground text-balance">
              Tell us about your day.
            </h2>
            <p className="mt-3 text-muted-foreground max-w-xl">
              Two required filters, two optional. The engine runs five rules (R1–R5) over a curated
              catalog of 45 garments.
            </p>
          </div>

          <form onSubmit={submit} className="grid gap-8">
            {/* Gender */}
            <fieldset>
              <Label className="text-xs uppercase tracking-[0.2em] text-muted-foreground">
                Gender <span className="text-primary">*</span>
              </Label>
              <div className="mt-3 flex flex-wrap gap-2">
                {VALID_GENDERS.map((g) => (
                  <button
                    type="button"
                    key={g}
                    onClick={() => setGender(g)}
                    className={`px-5 py-2.5 border text-sm transition-all ${
                      gender === g
                        ? "border-primary bg-primary/10 text-foreground"
                        : "border-border hover:border-primary/40 text-foreground/80"
                    }`}
                  >
                    {cap(g)}
                  </button>
                ))}
              </div>
            </fieldset>

            {/* Occasion */}
            <fieldset>
              <Label className="text-xs uppercase tracking-[0.2em] text-muted-foreground">
                Occasion <span className="text-primary">*</span>
              </Label>
              <div className="mt-3 flex flex-wrap gap-2">
                {VALID_OCCASIONS.map((o) => (
                  <button
                    type="button"
                    key={o}
                    onClick={() => setOccasion(o)}
                    className={`px-5 py-2.5 border text-sm transition-all ${
                      occasion === o
                        ? "border-primary bg-primary/10 text-foreground"
                        : "border-border hover:border-primary/40 text-foreground/80"
                    }`}
                  >
                    {cap(o)}
                  </button>
                ))}
              </div>
            </fieldset>

            <div className="grid md:grid-cols-2 gap-6">
              {/* Clothing type */}
              <fieldset>
                <Label htmlFor="clothing_type" className="text-xs uppercase tracking-[0.2em] text-muted-foreground">
                  Clothing type <span className="text-muted-foreground/60">(optional)</span>
                </Label>
                <Input
                  id="clothing_type"
                  value={clothingType}
                  onChange={(e) => setClothingType(e.target.value)}
                  placeholder="e.g. shirt, saree, kurta, jeans"
                  maxLength={40}
                  className="mt-3 h-11 bg-background border-border focus-visible:ring-primary rounded-none"
                />
              </fieldset>

              {/* Color preference */}
              <fieldset>
                <Label htmlFor="color" className="text-xs uppercase tracking-[0.2em] text-muted-foreground">
                  Color preference <span className="text-muted-foreground/60">(optional)</span>
                </Label>
                <Input
                  id="color"
                  list="color-groups"
                  value={colorPref}
                  onChange={(e) => setColorPref(e.target.value)}
                  placeholder="e.g. white, navy, or a group: light/dark/vibrant/neutral"
                  maxLength={40}
                  className="mt-3 h-11 bg-background border-border focus-visible:ring-primary rounded-none"
                />
                <datalist id="color-groups">
                  {colorGroupNames.map((g) => (
                    <option key={g} value={g} />
                  ))}
                </datalist>
                <p className="mt-2 text-xs text-muted-foreground">
                  Groups: {colorGroupNames.join(" · ")}
                </p>
              </fieldset>
            </div>

            {error && (
              <div className="flex items-start gap-2 text-sm text-destructive">
                <AlertCircle className="h-4 w-4 mt-0.5 shrink-0" />
                <p>{error}</p>
              </div>
            )}

            <div className="flex flex-wrap items-center gap-3 pt-2">
              <Button
                type="submit"
                disabled={loading}
                className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-none px-8 h-12"
              >
                {loading ? (
                  <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Filtering…</>
                ) : (
                  <><Sparkles className="mr-2 h-4 w-4" /> Recommend garments</>
                )}
              </Button>
              {result && (
                <Button type="button" variant="ghost" onClick={reset} className="text-muted-foreground">
                  Reset
                </Button>
              )}
            </div>
          </form>
        </div>
      </section>

      {result && <ResultsBlock result={result} />}
    </>
  );
}

function ResultsBlock({ result }: { result: RecommendResult }) {
  return (
    <section id="results" className="border-t border-border bg-background">
      <div className="mx-auto max-w-6xl px-6 py-16 md:py-24">
        <div className="mb-10 flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="text-xs uppercase tracking-[0.25em] text-primary mb-3">Results</p>
            <h2 className="font-display text-3xl md:text-4xl text-foreground">{result.message}</h2>
          </div>
          <div className="flex flex-wrap gap-2">
            {result.applied_filters.map((f) => (
              <span
                key={f}
                className="px-3 py-1.5 text-xs uppercase tracking-wider border border-border bg-secondary text-secondary-foreground"
              >
                {f}
              </span>
            ))}
          </div>
        </div>

        {result.total === 0 ? (
          <div className="border border-dashed border-border p-10 text-center bg-card">
            <Shirt className="h-8 w-8 mx-auto text-muted-foreground" />
            <p className="mt-4 text-muted-foreground max-w-md mx-auto">{result.message}</p>
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {result.recommendations.map((g) => (
              <article
                key={g.id}
                className="group bg-card border border-border hover:border-primary/50 transition-colors"
              >
                <div className="aspect-[4/5] bg-secondary relative overflow-hidden">
                  <img
                    src={getGarmentImageUrl(g)}
                    alt={g.name}
                    loading="lazy"
                    className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute top-3 left-3 flex gap-1.5">
                    <span className="px-2 py-0.5 text-[10px] uppercase tracking-wider bg-foreground/80 text-background backdrop-blur-sm">
                      {g.occasion}
                    </span>
                  </div>
                  <div className="absolute bottom-3 right-3">
                    <span className="font-display text-2xl text-background drop-shadow-lg">#{g.id}</span>
                  </div>
                </div>
                <div className="p-5">
                  <h3 className="font-display text-xl text-foreground leading-tight">{g.name}</h3>
                  <p className="mt-3 text-sm text-muted-foreground leading-relaxed">{g.description}</p>
                  <dl className="mt-4 grid grid-cols-3 gap-2 text-xs">
                    <Meta label="Gender" value={g.gender} />
                    <Meta label="Type" value={g.clothing_type.replace(/_/g, " ")} />
                    <Meta label="Color" value={g.color} />
                  </dl>
                </div>
              </article>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}

function Meta({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <dt className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</dt>
      <dd className="mt-0.5 text-foreground/90 capitalize">{value}</dd>
    </div>
  );
}
