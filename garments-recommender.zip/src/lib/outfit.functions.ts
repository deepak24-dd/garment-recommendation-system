import { createServerFn } from "@tanstack/react-start";
import { generateObject } from "ai";
import { z } from "zod";
import { getLovableAI } from "./ai-gateway";

const VALID_COLORS = [
  "white", "black", "navy", "blue", "sky blue", "grey", "charcoal",
  "cream", "yellow", "gold", "pink", "red", "maroon", "orange",
  "green", "purple", "multicolor",
] as const;

const VALID_TYPES = [
  "shirt", "tshirt", "jeans", "trouser", "shorts", "blazer", "suit",
  "jacket", "hoodie", "vest", "kurta", "kurti", "saree", "lehenga",
  "anarkali", "salwar_kameez", "sherwani", "kurta_pajama", "bandhgala",
  "dhoti_kurta", "ethnic", "dress", "skirt", "top", "jersey",
  "trackpants", "leggings", "yoga_pants", "pantsuit",
] as const;

const Schema = z.object({
  detected_type: z.enum(VALID_TYPES).describe("Closest matching clothing type"),
  detected_color: z.enum(VALID_COLORS).describe("Dominant color of the garment"),
  description: z.string().min(5).max(200).describe("One-sentence description of the outfit"),
  suggested_occasion: z.enum(["casual", "formal", "wedding", "sports", "festival"]),
});

export const analyzeOutfit = createServerFn({ method: "POST" })
  .inputValidator((input: { imageDataUrl: string }) => {
    if (!input?.imageDataUrl?.startsWith("data:image/")) {
      throw new Error("Invalid image data");
    }
    if (input.imageDataUrl.length > 8 * 1024 * 1024) {
      throw new Error("Image too large (max ~6MB)");
    }
    return input;
  })
  .handler(async ({ data }) => {
    const ai = getLovableAI();
    const model = ai("google/gemini-2.5-flash");

    const { object } = await generateObject({
      model,
      schema: Schema,
      messages: [
        {
          role: "system",
          content:
            "You are a fashion stylist. Analyze the garment in the image and pick the closest matching values from the provided enums. Always pick from the allowed values, never invent new ones.",
        },
        {
          role: "user",
          content: [
            { type: "text", text: "Analyze this outfit and identify the clothing type, dominant color, suitable occasion, and a brief description." },
            { type: "image", image: data.imageDataUrl },
          ],
        },
      ],
    });

    return object;
  });
