// Real garment photos, mapped by clothing_type, optional gender, and optional color.
import shirt from "@/assets/garments/shirt.jpg";
import shirtFemale from "@/assets/garments/shirt_female.jpg";
import shirtBlack from "@/assets/garments/shirt_black.jpg";
import shirtWhite from "@/assets/garments/shirt_white.jpg";
import shirtBlue from "@/assets/garments/shirt_blue.jpg";
import shirtYellow from "@/assets/garments/shirt_yellow.jpg";
import tshirt from "@/assets/garments/tshirt.jpg";
import tshirtFemale from "@/assets/garments/tshirt_female.jpg";
import tshirtBlack from "@/assets/garments/tshirt_black.jpg";
import tshirtWhite from "@/assets/garments/tshirt_white.jpg";
import tshirtBlue from "@/assets/garments/tshirt_blue.jpg";
import tshirtYellow from "@/assets/garments/tshirt_yellow.jpg";
import jeans from "@/assets/garments/jeans.jpg";
import jeansFemale from "@/assets/garments/jeans_female.jpg";
import jeansBlack from "@/assets/garments/jeans_black.jpg";
import jeansWhite from "@/assets/garments/jeans_white.jpg";
import jeansBlue from "@/assets/garments/jeans_blue.jpg";
import trouser from "@/assets/garments/trouser.jpg";
import trouserFemale from "@/assets/garments/trouser_female.jpg";
import shorts from "@/assets/garments/shorts.jpg";
import shortsFemale from "@/assets/garments/shorts_female.jpg";
import blazer from "@/assets/garments/blazer.jpg";
import blazerFemale from "@/assets/garments/blazer_female.jpg";
import suit from "@/assets/garments/suit.jpg";
import jacket from "@/assets/garments/jacket.jpg";
import jacketFemale from "@/assets/garments/jacket_female.jpg";
import hoodie from "@/assets/garments/hoodie.jpg";
import vest from "@/assets/garments/vest.jpg";
import kurta from "@/assets/garments/kurta.jpg";
import kurti from "@/assets/garments/kurti.jpg";
import saree from "@/assets/garments/saree.jpg";
import lehenga from "@/assets/garments/lehenga.jpg";
import anarkali from "@/assets/garments/anarkali.jpg";
import salwarKameez from "@/assets/garments/salwar_kameez.jpg";
import sherwani from "@/assets/garments/sherwani.jpg";
import kurtaPajama from "@/assets/garments/kurta_pajama.jpg";
import bandhgala from "@/assets/garments/bandhgala.jpg";
import dhotiKurta from "@/assets/garments/dhoti_kurta.jpg";
import ethnic from "@/assets/garments/ethnic.jpg";
import dress from "@/assets/garments/dress.jpg";
import dressBlack from "@/assets/garments/dress_black.jpg";
import dressWhite from "@/assets/garments/dress_white.jpg";
import dressBlue from "@/assets/garments/dress_blue.jpg";
import dressYellow from "@/assets/garments/dress_yellow.jpg";
import skirt from "@/assets/garments/skirt.jpg";
import top from "@/assets/garments/top.jpg";
import jersey from "@/assets/garments/jersey.jpg";
import jerseyFemale from "@/assets/garments/jersey_female.jpg";
import trackpants from "@/assets/garments/trackpants.jpg";
import leggings from "@/assets/garments/leggings.jpg";
import yogaPants from "@/assets/garments/yoga_pants.jpg";
import pantsuit from "@/assets/garments/pantsuit.jpg";

// Default image per clothing_type (used for male/unisex or when no gender variant exists)
const TYPE_MAP: Record<string, string> = {
  shirt, tshirt, jeans, trouser, shorts, blazer, suit, jacket, hoodie, vest,
  kurta, kurti, saree, lehenga, anarkali, salwar_kameez: salwarKameez,
  sherwani, kurta_pajama: kurtaPajama, bandhgala, dhoti_kurta: dhotiKurta,
  ethnic, dress, skirt, top, jersey, trackpants, leggings,
  yoga_pants: yogaPants, pantsuit,
};

// Gender-specific overrides for shared types
const FEMALE_MAP: Record<string, string> = {
  shirt: shirtFemale, tshirt: tshirtFemale, jeans: jeansFemale,
  trouser: trouserFemale, shorts: shortsFemale, blazer: blazerFemale,
  jacket: jacketFemale, jersey: jerseyFemale,
};

// Color-specific overrides — keyed as `${type}_${color}`
const COLOR_MAP: Record<string, string> = {
  shirt_black: shirtBlack, shirt_white: shirtWhite, shirt_blue: shirtBlue, shirt_yellow: shirtYellow,
  tshirt_black: tshirtBlack, tshirt_white: tshirtWhite, tshirt_blue: tshirtBlue, tshirt_yellow: tshirtYellow,
  jeans_black: jeansBlack, jeans_white: jeansWhite, jeans_blue: jeansBlue,
  dress_black: dressBlack, dress_white: dressWhite, dress_blue: dressBlue, dress_yellow: dressYellow,
};

// Map a free-form color string to one of the supported color buckets.
function normalizeColor(color: string): string | null {
  const c = color.trim().toLowerCase();
  if (!c) return null;
  if (c.includes("black") || c.includes("charcoal")) return "black";
  if (c.includes("white") || c.includes("cream") || c.includes("ivory")) return "white";
  if (c.includes("blue") || c.includes("navy") || c.includes("denim") || c.includes("sky")) return "blue";
  if (c.includes("yellow") || c.includes("mustard") || c.includes("gold")) return "yellow";
  return null;
}

export function getGarmentImageUrl(opts: {
  id: number;
  clothing_type: string;
  color: string;
  gender?: string;
}): string {
  const key = opts.clothing_type.trim().toLowerCase();
  const gender = opts.gender?.trim().toLowerCase();
  const colorBucket = normalizeColor(opts.color);

  // 1. Color-specific variant (highest priority)
  if (colorBucket) {
    const colorKey = `${key}_${colorBucket}`;
    if (COLOR_MAP[colorKey]) return COLOR_MAP[colorKey];
  }
  // 2. Gender-specific variant
  if (gender === "female" && FEMALE_MAP[key]) return FEMALE_MAP[key];
  // 3. Default per clothing type
  return TYPE_MAP[key] ?? shirt;
}
