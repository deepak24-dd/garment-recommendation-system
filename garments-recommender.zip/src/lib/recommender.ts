import { supabase } from "@/integrations/supabase/client";

// ──────────────────────────────────────────────
// Constants — mirrored from recommender.py
// ──────────────────────────────────────────────
export const VALID_GENDERS = ["male", "female", "unisex"] as const;
export const VALID_OCCASIONS = ["casual", "formal", "wedding", "sports", "festival"] as const;

export const COLOR_GROUPS: Record<string, string[]> = {
  light: ["white", "cream", "yellow", "pink", "sky blue", "blue", "gold"],
  dark: ["black", "navy", "maroon", "grey", "charcoal"],
  vibrant: ["red", "orange", "green", "purple", "multicolor"],
  neutral: ["white", "cream", "grey", "black", "navy"],
};

export type Gender = (typeof VALID_GENDERS)[number];
export type Occasion = (typeof VALID_OCCASIONS)[number];

export type Garment = {
  id: number;
  name: string;
  gender: string;
  occasion: string;
  clothing_type: string;
  color: string;
  description: string;
};

export type RecommendResult = {
  recommendations: Garment[];
  applied_filters: string[];
  message: string;
  total: number;
};

const norm = (v: string) => v.trim().toLowerCase();

export function validateInputs(gender: string, occasion: string): { ok: true } | { ok: false; error: string } {
  if (!(VALID_GENDERS as readonly string[]).includes(norm(gender))) {
    return { ok: false, error: `Invalid gender '${gender}'. Please choose from: ${VALID_GENDERS.join(", ")}.` };
  }
  if (!(VALID_OCCASIONS as readonly string[]).includes(norm(occasion))) {
    return { ok: false, error: `Invalid occasion '${occasion}'. Please choose from: ${VALID_OCCASIONS.join(", ")}.` };
  }
  return { ok: true };
}

// ──────────────────────────────────────────────
// Core rule-based recommendation engine
// (Mirrors recommender.py: R1–R5)
// ──────────────────────────────────────────────
export async function getRecommendations(
  genderRaw: string,
  occasionRaw: string,
  clothingTypeRaw = "",
  colorPreferenceRaw = "",
): Promise<RecommendResult> {
  const gender = norm(genderRaw);
  const occasion = norm(occasionRaw);
  const clothingType = norm(clothingTypeRaw);
  const colorPreference = norm(colorPreferenceRaw);

  const v = validateInputs(gender, occasion);
  if (!v.ok) {
    return { recommendations: [], applied_filters: [], message: v.error, total: 0 };
  }

  // R1 + R2 done at the database level for efficiency
  const { data, error } = await supabase
    .from("garments")
    .select("*")
    .in("gender", [gender, "unisex"])
    .eq("occasion", occasion)
    .order("id", { ascending: true });

  if (error) {
    return {
      recommendations: [],
      applied_filters: [],
      message: `Database error: ${error.message}`,
      total: 0,
    };
  }

  let results: Garment[] = (data ?? []) as Garment[];
  const appliedFilters: string[] = [`Gender = ${gender}`, `Occasion = ${occasion}`];

  // R3: clothing-type filter (optional, soft)
  if (clothingType) {
    const typeFiltered = results.filter((g) => {
      const ct = norm(g.clothing_type);
      return ct.includes(clothingType) || clothingType.includes(ct);
    });
    if (typeFiltered.length > 0) {
      results = typeFiltered;
      appliedFilters.push(`Clothing type = ${clothingType}`);
    }
  }

  // R4: color preference filter (optional, soft) — supports color-group names
  if (colorPreference) {
    let colorFiltered: Garment[];
    if (colorPreference in COLOR_GROUPS) {
      const groupColors = COLOR_GROUPS[colorPreference];
      colorFiltered = results.filter((g) => {
        const c = norm(g.color);
        return groupColors.some((gc) => c.includes(gc)) || groupColors.includes(c);
      });
    } else {
      colorFiltered = results.filter((g) => {
        const c = norm(g.color);
        return c.includes(colorPreference) || colorPreference.includes(c);
      });
    }
    if (colorFiltered.length > 0) {
      results = colorFiltered;
      appliedFilters.push(`Color preference = ${colorPreference}`);
    }
    // R5 fallback: if filter wiped results, keep pre-color results
  }

  const total = results.length;
  let message: string;
  if (total === 0) {
    message =
      "No garments matched all your filters. Try broadening your search (e.g., remove clothing type or color).";
  } else if (total === 1) {
    message = "1 garment found matching your preferences.";
  } else {
    message = `${total} garment(s) found matching your preferences.`;
  }

  return { recommendations: results, applied_filters: appliedFilters, message, total };
}
