import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { getRecommendations } from "./recommender";

const InputSchema = z.object({
  gender: z.string().min(1).max(20),
  occasion: z.string().min(1).max(20),
  clothing_type: z.string().max(40).optional().default(""),
  color_preference: z.string().max(40).optional().default(""),
});

export const recommendGarments = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => InputSchema.parse(input))
  .handler(async ({ data }) => {
    return await getRecommendations(
      data.gender,
      data.occasion,
      data.clothing_type,
      data.color_preference,
    );
  });
