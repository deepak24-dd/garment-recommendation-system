import { createFileRoute } from "@tanstack/react-router";
import { getRecommendations } from "@/lib/recommender";

const corsHeaders = {
  "Content-Type": "application/json",
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
};

// Public JSON API — mirrors Flask's /api/recommend
// Usage: /api/public/recommend?gender=male&occasion=formal&clothing_type=shirt&color=white
export const Route = createFileRoute("/api/public/recommend")({
  server: {
    handlers: {
      OPTIONS: async () => new Response(null, { status: 204, headers: corsHeaders }),
      GET: async ({ request }) => {
        const url = new URL(request.url);
        const gender = url.searchParams.get("gender") ?? "";
        const occasion = url.searchParams.get("occasion") ?? "";
        const clothingType = url.searchParams.get("clothing_type") ?? "";
        const color = url.searchParams.get("color") ?? "";

        const result = await getRecommendations(gender, occasion, clothingType, color);
        return new Response(JSON.stringify(result, null, 2), { status: 200, headers: corsHeaders });
      },
    },
  },
});
