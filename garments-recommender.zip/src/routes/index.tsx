import { createFileRoute } from "@tanstack/react-router";
import heroImage from "@/assets/hero.jpg";
import { RecommenderForm } from "@/components/RecommenderForm";
import { OutfitChecker } from "@/components/OutfitChecker";
import { Button } from "@/components/ui/button";
import { ArrowDown, Code2 } from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Garments Recommendation System — MCA Major Project" },
      {
        name: "description",
        content:
          "A rule-based garments recommendation system. Enter gender, occasion, and optional clothing type and color preference to get curated outfit suggestions from a 45-item catalog.",
      },
      { property: "og:title", content: "Garments Recommendation System" },
      {
        property: "og:description",
        content: "Rule-based fashion recommendations · MCA Major Project · Manipal University Jaipur.",
      },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <main className="min-h-screen bg-background">
      <Hero />
      <RecommenderForm />
      <OutfitChecker />
      <RulesSection />
      <ApiSection />
      <Footer />
    </main>
  );
}

function Hero() {
  return (
    <section className="relative">
      <div className="mx-auto max-w-7xl px-6 pt-8">
        <header className="flex items-center justify-between py-4">
          <div className="flex items-center gap-2">
            <div className="h-2 w-2 rounded-full bg-primary" />
            <span className="font-display text-xl tracking-tight">Atelier · GRS</span>
          </div>
          <span className="hidden sm:inline text-xs uppercase tracking-[0.3em] text-muted-foreground">
            MCA Major Project · 2025-26
          </span>
        </header>
      </div>

      <div className="mx-auto max-w-7xl px-6 pt-12 md:pt-20 pb-16 md:pb-20">
        <div className="grid md:grid-cols-12 gap-10 items-end">
          <div className="md:col-span-7">
            <p className="text-xs uppercase tracking-[0.3em] text-primary mb-6">
              Garments Recommendation System
            </p>
            <h1 className="font-display text-5xl md:text-7xl leading-[0.98] text-foreground text-balance">
              The right outfit, <em className="italic text-primary">picked</em> by a few clean rules.
            </h1>
            <p className="mt-8 max-w-xl text-lg text-muted-foreground leading-relaxed">
              A rule-based engine over a 45-garment catalog. Pick a gender and occasion;
              optionally narrow by clothing type or color group.
            </p>
            <div className="mt-10 flex items-center gap-6">
              <Button
                size="lg"
                onClick={() =>
                  document.getElementById("recommend")?.scrollIntoView({ behavior: "smooth" })
                }
                className="bg-foreground text-background hover:bg-foreground/90 rounded-none px-8 h-12"
              >
                Try the recommender <ArrowDown className="ml-2 h-4 w-4" />
              </Button>
              <a
                href="#api"
                className="text-sm text-muted-foreground hover:text-foreground inline-flex items-center gap-1.5"
              >
                <Code2 className="h-4 w-4" /> JSON API
              </a>
            </div>

            <dl className="mt-12 grid grid-cols-3 gap-6 max-w-md border-t border-border pt-6">
              <Stat n="45" l="Garments" />
              <Stat n="5" l="Occasions" />
              <Stat n="R1–R5" l="Rules" />
            </dl>
          </div>

          <div className="md:col-span-5">
            <div className="relative aspect-[3/4] overflow-hidden bg-secondary">
              <img
                src={heroImage}
                alt="Editorial fashion photography in terracotta and sage tones"
                width={1536}
                height={1024}
                className="h-full w-full object-cover"
              />
              <div className="absolute bottom-4 left-4 right-4 flex items-end justify-between text-xs text-background/90">
                <span className="bg-foreground/40 backdrop-blur-sm px-3 py-1.5 uppercase tracking-widest">
                  Catalog · 2026
                </span>
              </div>
            </div>
            <div className="mt-3 flex items-center justify-between text-xs text-muted-foreground">
              <span>DeshDeepak · 2424150104</span>
              <span>Guide: Dr. Aradhana Kar</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function Stat({ n, l }: { n: string; l: string }) {
  return (
    <div>
      <dt className="font-display text-3xl text-primary">{n}</dt>
      <dd className="mt-1 text-xs uppercase tracking-wider text-muted-foreground">{l}</dd>
    </div>
  );
}

function RulesSection() {
  const rules = [
    { id: "R1", name: "Gender", required: true, desc: "Match male / female; unisex items show to everyone." },
    { id: "R2", name: "Occasion", required: true, desc: "Match casual, formal, wedding, sports, or festival." },
    { id: "R3", name: "Clothing type", required: false, desc: "Optional substring keyword match (shirt, saree…)." },
    { id: "R4", name: "Color preference", required: false, desc: "Direct color OR a group (light/dark/vibrant/neutral)." },
    { id: "R5", name: "Fallback", required: false, desc: "Auto-relax R3/R4 if no items remain." },
  ];
  return (
    <section className="border-t border-border bg-card">
      <div className="mx-auto max-w-6xl px-6 py-16 md:py-20">
        <p className="text-xs uppercase tracking-[0.25em] text-primary mb-3">Methodology</p>
        <h2 className="font-display text-3xl md:text-4xl text-foreground max-w-2xl text-balance">
          Five rules, applied in order.
        </h2>
        <div className="mt-10 grid md:grid-cols-5 gap-4">
          {rules.map((r) => (
            <div key={r.id} className="border border-border p-5 bg-background">
              <div className="flex items-baseline justify-between">
                <span className="font-display text-2xl text-primary">{r.id}</span>
                <span className={`text-[10px] uppercase tracking-wider ${r.required ? "text-foreground" : "text-muted-foreground"}`}>
                  {r.required ? "Required" : "Optional"}
                </span>
              </div>
              <h3 className="mt-3 font-display text-lg text-foreground">{r.name}</h3>
              <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{r.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function ApiSection() {
  const example = "/api/public/recommend?gender=male&occasion=formal&clothing_type=shirt&color=white";
  return (
    <section id="api" className="border-t border-border bg-background">
      <div className="mx-auto max-w-6xl px-6 py-16 md:py-20">
        <div className="grid md:grid-cols-2 gap-10 items-start">
          <div>
            <p className="text-xs uppercase tracking-[0.25em] text-primary mb-3">For developers</p>
            <h2 className="font-display text-3xl md:text-4xl text-foreground text-balance">
              A JSON API, the same logic.
            </h2>
            <p className="mt-4 text-muted-foreground leading-relaxed">
              The recommendation engine is also exposed as a public REST endpoint, mirroring the
              Flask <code className="font-mono text-foreground">/api/recommend</code> route from the project.
              Returns the matched garments, applied filters, and a status message.
            </p>
            <a
              href={example}
              target="_blank"
              rel="noreferrer"
              className="mt-6 inline-flex items-center gap-2 text-sm text-primary hover:underline underline-offset-4"
            >
              <Code2 className="h-4 w-4" /> Open the live example
            </a>
          </div>
          <div className="bg-card border border-border p-5 font-mono text-xs leading-relaxed overflow-x-auto">
            <p className="text-muted-foreground"># Request</p>
            <p className="text-foreground mt-1 break-all">GET {example}</p>
            <p className="text-muted-foreground mt-4"># Response</p>
            <pre className="text-foreground mt-1 whitespace-pre-wrap">{`{
  "recommendations": [
    {
      "id": 1,
      "name": "Classic White Formal Shirt",
      "gender": "male",
      "occasion": "formal",
      "clothing_type": "shirt",
      "color": "white",
      "description": "A crisp white cotton formal shirt..."
    }
  ],
  "applied_filters": [
    "Gender = male",
    "Occasion = formal",
    "Clothing type = shirt",
    "Color preference = white"
  ],
  "message": "2 garment(s) found matching your preferences.",
  "total": 2
}`}</pre>
          </div>
        </div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="border-t border-border bg-card">
      <div className="mx-auto max-w-7xl px-6 py-10 grid md:grid-cols-3 gap-6 text-sm text-muted-foreground">
        <div>
          <p className="font-display text-base text-foreground">Garments Recommendation System</p>
          <p className="mt-1">A rule-based fashion recommender.</p>
        </div>
        <div>
          <p className="text-xs uppercase tracking-[0.2em] text-foreground">Project</p>
          <p className="mt-2">Major Project · MCA · 2025-26</p>
          <p>Manipal University Jaipur</p>
        </div>
        <div>
          <p className="text-xs uppercase tracking-[0.2em] text-foreground">People</p>
          <p className="mt-2">DeshDeepak · Reg 2424150104</p>
          <p>Guide: Dr. Aradhana Kar</p>
        </div>
      </div>
    </footer>
  );
}
